// Product data from JSON
const productData = {
    quarterTurnLocks: [
        {"code": "LR-HDP", "name": "Full Metal Heavy Duty", "material": "ZAMAK-5", "description": "Heavy duty quarter turn lock with full metal construction", "series": "LR", "ipRating": "IP-65"},
        {"code": "NSLK-HDP", "name": "Knob Lock - Heavy", "material": "ZAMAK-5 + Polyamide", "description": "Heavy duty knob lock with polyamide knob", "series": "NSLK"},
        {"code": "NLR-IS", "name": "Rectangle Lock", "material": "Polyamide + ZAMAK-5", "description": "Rectangle body lock with metal insert", "series": "NLR"},
        {"code": "LEL", "name": "Polyamide and Metal Combo", "material": "Polyamide + MS", "description": "Combination lock with polyamide body", "series": "LEL"},
        {"code": "LR-PL", "name": "Padlocking", "material": "Zinc Alloy", "description": "Padlocking quarter turn lock", "series": "LR"}
    ],
    threePointLocks: [
        {"code": "NTP-01", "name": "Round Rod", "material": "Polyamide PA6GF30", "description": "3 point lock with round rod mechanism", "series": "NTP", "rodType": "Round"},
        {"code": "NTP-01PL", "name": "Round Rod-Pad Lock", "material": "Polyamide PA6GF30", "description": "3 point lock with padlock feature", "series": "NTP", "rodType": "Round"},
        {"code": "NTP-01PCPU", "name": "Round Rod-IP", "material": "Polyamide PA6GF30", "description": "IP-65 rated 3 point lock", "series": "NTP", "ipRating": "IP-65", "rodType": "Round"},
        {"code": "NTP-02", "name": "Flat Rod", "material": "Polyamide PA6GF30 + ZAMAK-5", "description": "3 point lock with flat rod mechanism", "series": "NTP", "rodType": "Flat"},
        {"code": "NTP-05SF", "name": "Small Facia - Flat Rod", "material": "ZAMAK-5 + Polyamide", "description": "Compact 3 point lock with flat rod", "series": "NTP", "rodType": "Flat"}
    ],
    handles: [
        {"code": "NDH-02-8", "name": "U Rod Handle 8mm", "material": "MS/SS", "description": "U-shaped rod handle, chrome plated", "series": "NDH", "size": "Various lengths"},
        {"code": "NDH-02-10", "name": "U Rod Handle 10mm", "material": "MS/SS", "description": "10mm diameter U-rod handle", "series": "NDH", "size": "Various lengths"},
        {"code": "NDH-03", "name": "Polyamide Handle", "material": "Polyamide", "description": "115mm polyamide handle with brass insert", "series": "NDH", "size": "115mm"},
        {"code": "NDH-04", "name": "Pocket Handle", "material": "Polyamide", "description": "Small and big pocket handles", "series": "NDH", "type": "Pocket"},
        {"code": "NDH-10D", "name": "Pipe Handle", "material": "SS Pipe + Zamak-5 Base", "description": "Stainless steel pipe handle with zinc alloy base", "series": "NDH", "type": "Pipe"}
    ],
    hinges: [
        {"code": "NH-03", "name": "Concealed Hinge", "material": "MS", "description": "Various sizes concealed hinges", "series": "NH", "type": "Concealed"},
        {"code": "NH-05P", "name": "Hinge - Polyamide", "material": "Polyamide", "description": "Polyamide concealed hinge", "series": "NH", "type": "Concealed"},
        {"code": "NH-05Z", "name": "Hinge - Zinc Alloy", "material": "Zinc Alloy", "description": "Zinc alloy concealed hinge with bolts", "series": "NH", "type": "Concealed"},
        {"code": "NH-07", "name": "MS Hinge", "material": "MS", "description": "Standard MS hinge with tapping option", "series": "NH", "type": "Standard"},
        {"code": "NH-03SS", "name": "Stainless Steel Hinge", "material": "Stainless Steel", "description": "Corrosion resistant SS hinge", "series": "NH", "material": "Stainless Steel"}
    ],
    canopyLocks: [
        {"code": "NCL-01SS", "name": "Canopy Lock SS", "material": "Stainless Steel", "description": "Stainless steel canopy lock", "series": "NCL"},
        {"code": "NCL-02", "name": "Canopy Lock T-Handle", "material": "SS", "description": "T-handle type canopy lock", "series": "NCL"},
        {"code": "CAL", "name": "Castle Interlock", "material": "SS", "description": "Castle interlock clockwise/anticlockwise", "series": "CAL"},
        {"code": "CALS", "name": "Castle Interlock Square", "material": "SS", "description": "Square type castle interlock", "series": "CALS"}
    ],
    gaskets: [
        {"code": "NG-01", "name": "Top Bubble Gasket", "material": "EPDM", "description": "EPDM top bubble gasket with metal insert", "series": "NG", "ipRating": "IP-65"},
        {"code": "NG-02", "name": "Side Bubble Gasket", "material": "EPDM", "description": "EPDM side bubble gasket various sizes", "series": "NG", "ipRating": "IP-65"},
        {"code": "NG-03", "name": "U Gasket", "material": "EPDM", "description": "U-shaped EPDM gasket", "series": "NG"},
        {"code": "NG-04", "name": "H Gasket", "material": "EPDM", "description": "H-profile EPDM gasket", "series": "NG"},
        {"code": "NSAFG", "name": "Self Adhesive Foam", "material": "XLPE", "description": "Cross-linked polyethylene foam gasket", "series": "NSAFG"}
    ],
    others: [
        {"code": "NAC-BP", "name": "Bolted Panel Accessories", "material": "MS/Zinc", "description": "Various accessories for bolted panels", "series": "NAC"},
        {"code": "NLP", "name": "Legend Plates", "material": "Polyamide/Aluminium", "description": "Legend plates and stickers", "series": "NLP"},
        {"code": "CH-01", "name": "MCB DIN Rail", "material": "CR Steel", "description": "MCB channel blue/yellow", "series": "CH"},
        {"code": "CNR-BLK", "name": "Corner Block", "material": "ZAMAK-5", "description": "Zinc alloy corner block", "series": "CNR"}
    ]
};

// Category names mapping
const categoryNames = {
    quarterTurnLocks: "Quarter Turn Locks",
    threePointLocks: "3 Point Locks", 
    handles: "Handles",
    hinges: "Hinges",
    canopyLocks: "Canopy/Castle Locks",
    gaskets: "Gaskets",
    others: "Others/Accessories"
};

// Current filters and search
let currentFilters = {
    category: '',
    material: '',
    search: ''
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing app...');
    initializeNavigation();
    initializeMobileMenu();
    initializeProducts();
    initializeFilters();
    initializeContactForm();
    
    // Show home section by default
    showSection('home');
});

// Navigation functionality
function initializeNavigation() {
    console.log('Initializing navigation...');
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            console.log('Nav link clicked:', this.getAttribute('href'));
            e.preventDefault();
            const targetSection = this.getAttribute('href').substring(1);
            showSection(targetSection);
        });
    });
}

function showSection(sectionId) {
    console.log('Showing section:', sectionId);
    
    // Hide all sections
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.classList.remove('active');
        section.style.display = 'none';
    });
    
    // Show target section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        targetSection.style.display = 'block';
        console.log('Section shown:', sectionId);
    } else {
        console.error('Section not found:', sectionId);
    }
    
    // Update navigation
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    
    const activeLink = document.querySelector(`[href="#${sectionId}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
    
    // Close mobile menu if open
    const navMenu = document.querySelector('.nav-menu');
    if (navMenu) {
        navMenu.classList.remove('active');
    }
    
    // Scroll to top
    window.scrollTo(0, 0);
}

// Mobile menu functionality
function initializeMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navMenu = document.querySelector('.nav-menu');
    
    if (mobileMenuBtn && navMenu) {
        mobileMenuBtn.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.header')) {
                navMenu.classList.remove('active');
            }
        });
    }
}

// Product functionality
function initializeProducts() {
    console.log('Initializing products...');
    renderProducts();
}

function renderProducts(filteredData = null) {
    const productsGrid = document.getElementById('products-grid');
    if (!productsGrid) {
        console.error('Products grid not found');
        return;
    }
    
    productsGrid.innerHTML = '';
    
    const dataToRender = filteredData || getAllProducts();
    console.log('Rendering products:', dataToRender.length);
    
    if (dataToRender.length === 0) {
        productsGrid.innerHTML = '<div class="no-products" style="text-align: center; padding: 2rem; color: var(--color-text-secondary);">No products found matching your criteria.</div>';
        return;
    }
    
    dataToRender.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
}

function getAllProducts() {
    const allProducts = [];
    Object.keys(productData).forEach(category => {
        productData[category].forEach(product => {
            allProducts.push({...product, category});
        });
    });
    return allProducts;
}

function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    const ipRatingBadge = product.ipRating ? 
        `<span class="product-ip-rating">${product.ipRating}</span>` : '';
    
    card.innerHTML = `
        <div class="product-header">
            <div class="product-code">${product.code}</div>
            <div class="product-series">${product.series}</div>
        </div>
        <div class="product-name">${product.name}</div>
        <div class="product-material">Material: ${product.material}</div>
        <div class="product-description">${product.description}</div>
        <div class="product-footer">
            <span class="view-details">Click for details →</span>
            ${ipRatingBadge}
        </div>
    `;
    
    // Add click event listener
    card.addEventListener('click', function() {
        openProductModal(product);
    });
    
    return card;
}

// Filter functionality
function initializeFilters() {
    const searchInput = document.getElementById('product-search');
    const categoryFilter = document.getElementById('category-filter');
    const materialFilter = document.getElementById('material-filter');
    
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            currentFilters.search = this.value.toLowerCase();
            applyFilters();
        });
    }
    
    if (categoryFilter) {
        categoryFilter.addEventListener('change', function() {
            currentFilters.category = this.value;
            applyFilters();
        });
    }
    
    if (materialFilter) {
        materialFilter.addEventListener('change', function() {
            currentFilters.material = this.value;
            applyFilters();
        });
    }
}

function applyFilters() {
    let filteredProducts = getAllProducts();
    
    // Apply category filter
    if (currentFilters.category) {
        filteredProducts = filteredProducts.filter(product => 
            product.category === currentFilters.category);
    }
    
    // Apply material filter
    if (currentFilters.material) {
        filteredProducts = filteredProducts.filter(product =>
            product.material.includes(currentFilters.material));
    }
    
    // Apply search filter
    if (currentFilters.search) {
        filteredProducts = filteredProducts.filter(product =>
            product.name.toLowerCase().includes(currentFilters.search) ||
            product.code.toLowerCase().includes(currentFilters.search) ||
            product.description.toLowerCase().includes(currentFilters.search) ||
            product.material.toLowerCase().includes(currentFilters.search)
        );
    }
    
    renderProducts(filteredProducts);
}

function showProductCategory(category) {
    console.log('Showing product category:', category);
    showSection('products');
    
    // Set category filter
    const categoryFilter = document.getElementById('category-filter');
    if (categoryFilter) {
        categoryFilter.value = category;
        currentFilters.category = category;
    }
    
    // Clear other filters
    const searchInput = document.getElementById('product-search');
    const materialFilter = document.getElementById('material-filter');
    
    if (searchInput) {
        searchInput.value = '';
        currentFilters.search = '';
    }
    
    if (materialFilter) {
        materialFilter.value = '';
        currentFilters.material = '';
    }
    
    applyFilters();
}

// Modal functionality
function openProductModal(product) {
    console.log('Opening modal for product:', product.code);
    const modal = document.getElementById('product-modal');
    
    if (!modal) {
        console.error('Modal not found');
        return;
    }
    
    // Populate modal content
    const elements = {
        'modal-product-name': product.name,
        'modal-product-code': product.code,
        'modal-product-material': product.material,
        'modal-product-series': product.series,
        'modal-product-description': product.description
    };
    
    Object.keys(elements).forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = elements[id];
        }
    });
    
    // Handle IP rating
    const ipRatingItem = document.getElementById('modal-ip-rating-item');
    const ipRatingSpan = document.getElementById('modal-product-ip');
    
    if (product.ipRating && ipRatingItem && ipRatingSpan) {
        ipRatingSpan.textContent = product.ipRating;
        ipRatingItem.style.display = 'flex';
    } else if (ipRatingItem) {
        ipRatingItem.style.display = 'none';
    }
    
    // Add additional specs based on product type
    const specsContainer = document.getElementById('modal-technical-specs');
    if (specsContainer) {
        let additionalSpecs = '';
        
        if (product.rodType) {
            additionalSpecs += `<p><strong>Rod Type:</strong> ${product.rodType}</p>`;
        }
        if (product.size) {
            additionalSpecs += `<p><strong>Size:</strong> ${product.size}</p>`;
        }
        if (product.type) {
            additionalSpecs += `<p><strong>Type:</strong> ${product.type}</p>`;
        }
        
        additionalSpecs += `
            <p>Detailed technical drawings and specifications are available in our product catalogue.</p>
            <p>For specific dimensions and installation details, please refer to the respective product catalogue or contact our technical team at +91-80-23210113.</p>
        `;
        
        specsContainer.innerHTML = additionalSpecs;
    }
    
    // Show modal
    modal.classList.remove('hidden');
    modal.style.display = 'flex';
}

function closeModal() {
    const modal = document.getElementById('product-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
}

// Catalogue functionality
function downloadCatalogue(filename) {
    console.log('Downloading catalogue:', filename);
    alert(`Downloading ${filename}...\n\nNote: In a real application, this would download the actual PDF catalogue. Please contact us at snehi@pyramidbangalore.com for catalogue requests.`);
}

// Contact form functionality
function initializeContactForm() {
    const contactForm = document.getElementById('contact-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Contact form submitted');
            
            // Get form data
            const inputs = this.querySelectorAll('input, textarea');
            const name = inputs[0].value;
            const email = inputs[1].value;
            const company = inputs[2].value;
            const message = inputs[3].value;
            
            // Validate form
            if (!name || !email || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert('Please enter a valid email address.');
                return;
            }
            
            // Success message
            alert(`Thank you for your message, ${name}!\n\nWe will contact you at ${email} within 24 hours.\n\nFor immediate assistance, please call +91-80-23210113`);
            
            // Reset form
            this.reset();
        });
    }
}

// Close modal with escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeModal();
    }
});

// Handle window resize for responsive behavior
window.addEventListener('resize', debounce(() => {
    const navMenu = document.querySelector('.nav-menu');
    if (navMenu && window.innerWidth > 768) {
        navMenu.classList.remove('active');
    }
}, 250));

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Make functions globally available
window.showSection = showSection;
window.showProductCategory = showProductCategory;
window.openProductModal = openProductModal;
window.closeModal = closeModal;
window.downloadCatalogue = downloadCatalogue;

console.log('App.js loaded successfully');